/*
 * Public API Surface of im-common
 */
export {IMControlsModule} from 'im-common/im-controls';

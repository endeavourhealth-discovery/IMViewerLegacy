export class Concept {
  iri: string;
  name: string;
  description: string;
}
